<?php

	class Dashboard extends CI_Controller{

		 public function __construct()
		    {
		        parent::__construct();
		        $this->load->model('dashboard_model');

		    }

		public function dashboards(){
			if($this->session->userdata('logged')){
				
				$this->load->model('dashboard_model');
	       		$data["fetch_class"] = $this->dashboard_model->fetch_class($this->session->userdata('user_id'));
	       		//$data["fetch_sched"] = $this->dashboard_model->fetch_sched($this->session->userdata('user_id'));
				$this->load->view('templates/header');
				$this->load->view('pages/dashboard', $data);
				$this->load->view('templates/footer');

			}
			else
	        {
	            redirect('login/');
	        }
			
		}

		public function logout(){

			$this->session->unset_userdata('logged_in');
			$this->session->sess_destroy();
			redirect(site_url('login/user'), 'refresh');
		}
	}

