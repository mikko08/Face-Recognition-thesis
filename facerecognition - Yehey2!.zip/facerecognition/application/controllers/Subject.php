<?php

	class Subject extends CI_Controller{

		public function view_subjects(){
	        if($this->session->userdata('logged'))
	        {
				$this->load->model('subject_model');
	       		$data["fetch_data"] = $this->subject_model->fetch_data();
				$this->load->view('templates/header');
				$this->load->view('pages/subject', $data);
				$this->load->view('templates/footer');

	       	}
	        else
	        {
	            redirect('login/');
	        }
		}

		public function add_subject(){
	        if($this->session->userdata('logged'))
	        {
				$this->load->view('templates/header');
				$this->load->view('pages/add_subject');
				$this->load->view('templates/footer');
	       	}
	        else
	        {
	            redirect('login/');
	        }
		}

		public function input() {
	        if($this->session->userdata('logged'))
	        {

				if(
					$this->input->post('sub_code') != "" &&
					$this->input->post('sub_name') != ""
				)
				{
					$data['sub_code'] = $this->input->post('sub_code');
					$data['sub_name'] = $this->input->post('sub_name');
					$this->load->model('subject_model');
					$this->subject_model->insert($data);

				}
				else{
					
				}
	       	}
	        else
	        {
	            redirect('login/');
	        }

				redirect("Subject/view_subjects");
		}


		public function getEdit($sub_code){

			$this->load->model('subject_model');
			$data["subjects"] = $this->subject_model->get_edit_subject($sub_code);
			$this->load->view('templates/editHeader');
			$this->load->view('pages/edit_subject', $data);
			$this->load->view('templates/editFooter');


		}


		public function getEditSubject($sub_code) {
	        if($this->session->userdata('logged'))
	        {

				if(
					$this->input->post('sub_code') != "" &&
					$this->input->post('sub_name') != ""
				)
				{
					$data['sub_code'] = $this->input->post('sub_code', TRUE);
					$data['sub_name'] = $this->input->post('sub_name', TRUE);
					$this->load->model('subject_model');
					$this->subject_model->edit($data, $sub_code);

				}
				else{
					
				}
	       	}  

				redirect("Subject/view_subjects");
		}



	}

