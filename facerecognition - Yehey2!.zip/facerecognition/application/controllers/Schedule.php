<?php

	class Schedule extends CI_Controller{


		  public function __construct()
		    {
		        parent::__construct();
		        $this->load->model('schedule_model');

		    }

		public function view_schedule(){
	        if($this->session->userdata('logged'))
	        {
				$this->load->model('schedule_model');
	       		$data["fetch_data"] = $this->schedule_model->fetch_data($this->session->userdata('user_id'));
				$this->load->view('templates/header');
				$this->load->view('pages/schedule', $data);
				$this->load->view('templates/footer');
	        }
	        else
	        {
	            redirect('login/');
	        }
		}
		public function add_schedule(){

	        if($this->session->userdata('logged'))
	        {

	   // 		$this->load->model('class_model');
	        	$data['classes'] = $this->schedule_model->getClasses();
				$this->load->view('templates/header');
				$this->load->view('pages/add_schedule', $data);
				$this->load->view('templates/footer');

	        }
	      
		}

		public function input() {
	        if($this->session->userdata('logged'))
	        {
				if(
					$this->input->post('class_id') != "" &&
					$this->input->post('days') != "" &&
					$this->input->post('start') != "" &&
					$this->input->post('end_time') != ""

				)
				{
					$data['class_id'] = $this->input->post('class_id');
					$data['days'] = $this->input->post('days');
					$data['start'] = $this->input->post('start');
					$data['end_time'] = $this->input->post('end_time');
					$this->load->model('schedule_model');
					$this->schedule_model->insert($data);

				}
				else{
					
				}
	 
				redirect("Schedule/view_schedule");

			}
       		else
	        {
	            redirect('login/');
	        }
		}


		public function getEdit($sched_id){

			$this->load->model('schedule_model');
			$data["schedules"] = $this->schedule_model->get_edit_schedule($sched_id);
			$data["classes"] = $this->schedule_model->getClasses();
			// $data["starts"] = $this->schedule_model->getStartTime();
			// $data["ends"] = $this->schedule_model->getEndTime();
			$this->load->view('templates/editHeader');
			$this->load->view('pages/edit_schedule', $data);
			$this->load->view('templates/editFooter');


		}


		public function getEditSchedule($sched_id) {
	         if($this->session->userdata('logged'))
	        {
				if(
					$this->input->post('class_id') != "" &&
					$this->input->post('days') != "" &&
					$this->input->post('start') != "" &&
					$this->input->post('end_time') != ""

				)
				{
					$data['class_id'] = $this->input->post('class_id');
					$data['days'] = $this->input->post('days');
					$data['start'] = $this->input->post('start');
					$data['end_time'] = $this->input->post('end_time');
					$this->load->model('schedule_model');
					$this->schedule_model->edit($data, $sched_id);

				}
				else{
					
				}
	 
				redirect("Schedule/view_schedule");

			}
       		else
	        {
	            redirect('login/');
	        }
		}
}
