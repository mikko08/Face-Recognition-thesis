<?php

	class Subview extends CI_Controller{

		 public function __construct()
		    {
		        parent::__construct();
		        $this->load->model('subview_model');

		    }

		public function subview(){
			if($this->session->userdata('logged')){
				
				$this->load->model('subview_model');
			
				
				$data["subjects"] = $this->subview_model->fetch_sub($this->session->userdata('user_id'));
				
				$data["fetch_sect"] = $this->subview_model->fetch_sect($this->session->userdata('user_id'));

					$this->load->view('templates/header_sub',$data);
				$this->load->view('pages/subview', $data);

				$this->load->view('templates/footer_sub');

			}
			else
	        {
	            redirect('login/');
	        }
	    }


			
		

		

		public function logout(){

			$this->session->unset_userdata('logged_in');
			$this->session->sess_destroy();
			redirect(site_url('login/user'), 'refresh');
		}
	}

