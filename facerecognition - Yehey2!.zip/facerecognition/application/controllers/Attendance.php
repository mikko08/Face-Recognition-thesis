<?php

	class Attendance extends CI_Controller{

		 public function __construct()
		    {
		        parent::__construct();
		        $this->load->model('attendance_model');

		    }

		public function attendance(){
			if($this->session->userdata('logged')){
				
				$this->load->model('attendance_model');
			
				
				$data["att_d"] = $this->attendance_model->fetch_att($this->session->userdata('user_id'));
					$data["att_h"]= $this->attendance_model->att_h($this->session->userdata('user_id'));
				
				$data["fetch_sect"] = $this->attendance_model->fetch_sect($this->session->userdata('user_id'));

					$this->load->view('templates/header_sub',$data);
				$this->load->view('pages/attendance', $data);

				$this->load->view('templates/footer_sub');

			}
			else
	        {
	            redirect('login/');
	        }
	    }


			
		

		

		public function logout(){

			$this->session->unset_userdata('logged_in');
			$this->session->sess_destroy();
			redirect(site_url('login/user'), 'refresh');
		}
	}

