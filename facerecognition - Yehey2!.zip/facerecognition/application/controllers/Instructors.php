<?php

	class Instructors extends CI_Controller{

		public function view_instructor(){
			if($this->session->userdata('logged')){
				$data['title'] = 'Instructors';
				$this->load->model('instructor_model');
        		$data["fetch_data"] = $this->instructor_model->fetch_data();
				$this->load->view('templates/header', $data);
				$this->load->view('pages/instructors', $data);
				$this->load->view('templates/footer');
			}
			else
	        {
	            redirect('login/');
	        }
		}

		
		public function getEdit($ins_id){

			$this->load->model('instructor_model');
			$data["instructors"] = $this->instructor_model->get_edit_instructor($ins_id);
			$this->load->view('templates/editHeader');
			$this->load->view('pages/edit_instructor', $data);
			$this->load->view('templates/editFooter');


		}

		public function getEditInstructors($ins_id) {
	        if($this->session->userdata('logged'))
	        {

				if(
					$this->input->post('firstname') != "" &&
					$this->input->post('lastname') != ""
				)
				{	

					$data['firstname'] = $this->input->post('firstname', TRUE);
					$data['lastname'] = $this->input->post('lastname', TRUE);
					$this->load->model('instructor_model');
					$this->instructor_model->edit($data, $ins_id);

				}
				else{
					
				}
	       	}  

				redirect("Instructors/view_instructor");
		}



		public function add_instructor() {
	        if($this->session->userdata('logged'))
        	{
		        $this->load->view('templates/header');
		        $this->load->view('pages/add_instructor');
		        $this->load->view('templates/footer');
	       	}
	        else
	        {
	            redirect('login/');
	        }
   		}

   		public function input() {
        	if($this->session->userdata('logged'))
        	{
				if(
					$this->input->post('firstname') != "" &&
					$this->input->post('lastname') != ""
				)
				{
					$data['firstname'] = $this->input->post('firstname');
					$data['lastname'] = $this->input->post('lastname');
					$this->load->model('instructor_model');
					$this->instructor_model->insert($data);

				}
				else{
					
				}
	       	}
	        else
	        {
	            redirect('login/');
	        }
			redirect("Instructors/view_instructor");
			// redirect('index');
		}
	}