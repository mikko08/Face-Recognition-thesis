<?php

	class Students extends CI_Controller{


		 public function __construct()
		    {
		        parent::__construct();
		        $this->load->model('student_model');

		    }

		public function view_student(){
	        if($this->session->userdata('logged'))
	        {
				$this->load->model('student_model');
	       		$data["fetch_data"] = $this->student_model->fetch_data();
				$this->load->view('templates/header');
				$this->load->view('pages/students', $data);
				$this->load->view('templates/footer');		
	       	}
	        else
	        {
	            redirect('login/');
	        }
		}

		public function add_student(){
	        if($this->session->userdata('logged'))
	        {
	        	$data['sections'] = $this->student_model->getSection();
				$this->load->view('templates/header', $data);
				$this->load->view('pages/add_student', $data);
				$this->load->view('templates/footer');
	       	}
	        else
	        {
	            redirect('login/');
	        }
		}

		public function input() {
	        if($this->session->userdata('logged'))
	        {
				if(
					$this->input->post('firstname') != "" &&
					$this->input->post('lastname') != "" &&
					$this->input->post('sect_id') != ""
				)
				{

					$data['firstname'] = $this->input->post('firstname');
					$data['lastname'] = $this->input->post('lastname');
					$data['sect_id'] = $this->input->post('sect_id');
					$this->load->model('student_model');
					$this->student_model->insert($data);

				}
				else{
					
				}
			}
	        else
	        {
	            redirect('login/');
	        }
			redirect("Students/view_student");

		}

		public function getEdit($stud_id){

			$this->load->model('student_model');
			$data["students"] = $this->student_model->get_edit_students($stud_id);
			$data["sections"] = $this->student_model->getSection($stud_id);
			$this->load->view('templates/editHeader');
			$this->load->view('pages/edit_student', $data);
			$this->load->view('templates/editFooter');


		}


		public function getEditStudents($stud_id) {
	        if($this->session->userdata('logged'))
	        {
				if(
					$this->input->post('firstname') != "" &&
					$this->input->post('lastname') != "" &&
					$this->input->post('sect_id') != ""
				)
				{

					$data['firstname'] = $this->input->post('firstname', TRUE);
					$data['lastname'] = $this->input->post('lastname', TRUE);
					$data['sect_id'] = $this->input->post('sect_id', TRUE);
					$this->load->model('student_model');
					$this->student_model->edit($data, $stud_id);

				}
				else{
					
				}
			
	            

	        }

			redirect("Students/view_student");

		}


	}