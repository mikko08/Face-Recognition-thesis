<?php

	class View extends CI_Controller{

		 public function __construct()
		    {
		        parent::__construct();
		        $this->load->model('view_model');

		    }

		public function view(){
			if($this->session->userdata('logged')){
				
				$this->load->model('view_model');
				
				
				$data["sections"] = $this->view_model->fetch_view($this->session->userdata('user_id'));
				$data["fetch_sect"] = $this->view_model->fetch_sect($this->session->userdata('user_id'));
				$this->load->view('templates/header1', $data);
				$this->load->view('pages/view', $data);
				$this->load->view('templates/footer');

			}
			else
	        {
	            redirect('login/');
	        }
	    }


			
		

		

		public function logout(){

			$this->session->unset_userdata('logged_in');
			$this->session->sess_destroy();
			redirect(site_url('login/user'), 'refresh');
		}
	}

