<?php

	class Class_controller extends CI_Controller{


		  public function __construct()
		    {
		        parent::__construct();
		        $this->load->model('class_model');

		    }

		public function view_class(){
	        if($this->session->userdata('logged'))
	        {
				$this->load->model('class_model');
	       		$data["fetch_data"] = $this->class_model->fetch_data($this->session->userdata('user_id'));
				$this->load->view('templates/header');
				$this->load->view('pages/class', $data);
				$this->load->view('templates/footer');
	        }
	        else
	        {
	            redirect('login/');
	        }
		}
		public function add_class(){

	        if($this->session->userdata('logged'))
	        {

	        	// $this->load->model('class_model');
	        	$data['instructors'] = $this->class_model->getInstructor();
	        	// $data['subjects'] = $this->class_model->getSubject();
				$data['sections'] = $this->class_model->getSection();
				$this->load->view('templates/header');
				$this->load->view('pages/add_class', $data);
				$this->load->view('templates/footer');

	        }
	      
		}

		public function input() {
	        if($this->session->userdata('logged'))
	        {
				if(
					$this->input->post('ins_id') != "" &&
					$this->input->post('sect_id') != ""

				)
				{
					$data['ins_id'] = $this->input->post('ins_id');
					$data['sect_id'] = $this->input->post('sect_id');
					$this->load->model('class_model');
					$this->class_model->insert($data);

				}
				else{
					
				}
	 
				redirect("Class_controller/view_class");

			}
       		else
	        {
	            redirect('login/');
	        }
		}


		public function getEdit($class_id){

			$this->load->model('class_model');
			$data["classes"] = $this->class_model->get_edit_classes($class_id);
			$data['instructors'] = $this->class_model->getInstructor();
			$data['sections'] = $this->class_model->getSection();
			$this->load->view('templates/editHeader');
			$this->load->view('pages/edit_class', $data);
			$this->load->view('templates/editFooter');


		}


		public function getEditClasses($class_id) {
	        if($this->session->userdata('logged'))
	        {

				if(
					$this->input->post('ins_id') != "" &&
					$this->input->post('sect_id') != ""

				)
				{
					$data['ins_id'] = $this->input->post('ins_id', TRUE);
					$data['sect_id'] = $this->input->post('sect_id', TRUE);
					$this->load->model('class_model');
					$this->class_model->edit($data, $class_id);

				}
				else{
					
				}
	 
	       	}  

				redirect("Class_controller/view_class");
		}

}
