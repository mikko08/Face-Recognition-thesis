

  <!--NAVIGATION NAVIGATION NAVIGATION NAVIGATION NAVIGATION-->
  
  <div class="content-wrapper">
    <div class="container-fluid">
      <br/><br/><br/>
      
      <!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-table"></i> Attendance Record</div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">

             <thead>
              <tr>
                <th>Student Name</th>
              <!--  <?php var_dump($att_h) ?>  -->
                 <?php

              foreach ($att_h as $row) :
            ?>
                <th><?php echo $row->date;?></th>
         <?php
            endforeach;
            ?>
             </tr>
            </thead>
            <tbody>
        <!-- <?php var_dump($att_d) ?> --> 
        <?php
              foreach ($att_d as $row) {
            ?>
              <tr>  

               <td><?php echo $row->stud_id.'. ' . $row->lastname. ', ' . $row->firstname; ?></td>
               <td><?php echo $row->attend_status; ?></td>

              </tr>
        <?php
           }
            ?>
           
            </tbody>
          </table>
          </div>
        </div>
        <div class="card-footer small text-muted"><a  href="<?php echo base_url('view/view');?>" class="btn btn-warning">Back</a></div>

      </div>
    </div>
  </div>