
  <!--NAVIGATION NAVIGATION NAVIGATION NAVIGATION NAVIGATION-->

<div class="content-wrapper">
    <div class="container-fluid">
    <div class="col-sm-9 col-xs-9 col-md-10 col-lg-12">
      <div class="jumbotron jumbotron-home">
        <div class="container-fluid">
          <h1>Edit Class</h1><br/>
          

          <form class="form-horizontal" method="post" action="http://localhost/facerecognition/Class_controller/getEditClasses/<?php echo $classes['0']->class_id; ?>">
              <!-- <div class="form-group">
                <label for="username" class="col-sm-2 control-label">Subject Code</label>
                  <select class="form-control col-sm-3" name="sub_code">
                      <?php foreach($subjects as $row) { ?> 
                        <option value="<?php echo $row->sub_code; ?>"><?php echo $row->sub_code;?></option>';
                      <?php } ?> 
                  </select>
              </div> -->
              <div class="form-group">
                <label for="name" class="col-sm-2 control-label">Instructor</label>
                <select class="col-sm-3 form-control" name="ins_id">
                      <?php foreach($instructors as $row) { ?> 
                        <option value="<?php echo $row->ins_id; ?>"><?php echo $row->lastname;?></option>';
                      <?php } ?>
                </select>
              </div>
              <div class="form-group">
                <label for="name" class="col-sm-2 control-label">Section</label>
                <select class="form-control col-sm-3" name="sect_id">
                      <?php foreach($sections as $row) { ?> 
                        <option value="<?php echo $row->sect_id; ?>"><?php echo $row->year_level;?><?php echo $row->block_name;?></option>';
                      <?php } ?>
                </select>
              </div>
              <button class="btn btn-primary" type="submit" value="submit">Submit</button>
              <a class="btn btn-info" href="<?php echo base_url('Class_controller/view_class'); ?>">Cancel</a> 
          </form>

        </div>
      </div>
    </div>
  </div>
</div>

    <!-- Logout Modal-->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="<?= base_url(); ?>login/logout">Logout</a>
          </div>
        </div>
      </div>
    </div>