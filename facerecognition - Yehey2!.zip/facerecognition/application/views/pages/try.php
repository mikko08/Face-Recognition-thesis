<?php



	echo 'wala na insert!';