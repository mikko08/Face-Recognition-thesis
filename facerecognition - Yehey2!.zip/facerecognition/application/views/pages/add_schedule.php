
  <!--NAVIGATION NAVIGATION NAVIGATION NAVIGATION NAVIGATION-->

<div class="content-wrapper">
    <div class="container-fluid">
    <div class="col-sm-9 col-xs-9 col-md-10 col-lg-12">
      <div class="jumbotron jumbotron-home">
        <div class="container-fluid">
          <h1>Add Schedule</h1><br/>
          

          <form class="form-horizontal" method="post" action="http://localhost/facerecognition/Schedule/input">
              <div class="form-group">
                <label for="username" class="col-sm-2 control-label">Class</label>
                  <div class="col-sm-10">
                    <select class="form-control col-sm-3" name="class_id">
                        <?php foreach($classes as $row) { ?> 
                          <option value="<?php echo $row->class_id; ?>"><?php echo $row->class_id;?> - <?php echo $row->lastname;?>,<?php echo $row->firstname;?></option>';
                        <?php } ?> 
                    </select>
                  </div>
              </div>
              <div class="form-group">
                <label for="name" class="col-sm-2 control-label">Days</label>
                  <div class="col-sm-10">
                    <select class="form-control col-sm-3" name="days">
                      <option>Monday</option>
                      <option>Tuesday</option>
                      <option>Wednesday</option>
                      <option>Thursday</option>
                      <option>Friday</option>
                      <option>Saturday</option>
                    </select>
                  </div>
              </div>
              <div class="form-group">
                <label for="name" class="col-sm-2 control-label">Start time</label>
                  <div class="col-sm-3">
                    <input type="time" class="form-control" name="start" placeholder="Enter your start time" required />
                  </div>
              </div>
              <div class="form-group">
                <label for="name" class="col-sm-2 control-label">End time</label>
                  <div class="col-sm-3">
                    <input type="time" class="form-control" name="end_time" placeholder="Enter your end time" required/>
                  </div>
              </div>
              <button class="btn btn-primary" type="submit" value="submit">Submit</button>
              <a class="btn btn-info" href="view_schedule">View Schedule</a> 
          </form>

        </div>
      </div>
    </div>
  </div>
</div>

    <!-- Logout Modal-->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="<?= base_url(); ?>login/logout">Logout</a>
          </div>
        </div>
      </div>
    </div>