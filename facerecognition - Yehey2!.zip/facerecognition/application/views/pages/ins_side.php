        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="">
          <a class="nav-link nav-link-collapse" data-toggle="collapse" href="#collapseComponent">
            <i class="fa fa-fw fa-pencil"></i>
            <span class="nav-link-text">Show Sections</span>
          </a>
          <ul class="sidenav-second-level collapse" id="collapseComponent">
            <li>  
            <?php
              foreach ($fetch_sect as $row) {
            ?>
          
               <a href="<?php echo base_url('attendance/attendance/').$row->sect_id;?>"> <?php echo $row->year_level.'-'.$row->block_name; ?></a>

  

            <?php
            }
            ?>
            </li>

          </ul>
        </li>