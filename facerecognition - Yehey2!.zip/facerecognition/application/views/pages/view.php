
  <!--NAVIGATION NAVIGATION NAVIGATION NAVIGATION NAVIGATION-->
  
  <div class="content-wrapper">
    <div class="container-fluid">
      <br/><br/>
        <?php if($this->session->flashdata('welcome')){  ?>
        <div class="alert alert-success">
            <a href="#" class="close" data-dismiss="alert">&times;</a>
            <strong>Hello!</strong> <?php echo $this->session->flashdata('welcome'); ?>
        </div>
        <?php }?><br/>
      
      <!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-table"></i>Classes</div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">

             <thead>
              <tr>
                <th>Sections Listed</th>
                <th>Teacher Assigned</th>
       
             </tr>
            </thead>
            <tbody>

        <?php
              foreach ($sections as $row) {
            ?>
              <tr>  

               <td><?php echo $row->year_level.' - ' . $row->block_name; ?></td>
               <td><?php echo $row->lastname. ', ' . $row->firstname; ?></td>

              </tr>
        <?php
           }
            ?>
           
            </tbody>
          </table>
          </div>
        </div>
        <div class="card-footer small text-muted"><a  href="<?php echo base_url('view/view');?>" class="btn btn-warning">Back</a></div>

      </div>
  </div>