
  <!--NAVIGATION NAVIGATION NAVIGATION NAVIGATION NAVIGATION-->

<div class="content-wrapper">
    <div class="container-fluid">
		<div class="col-sm-9 col-xs-9 col-md-10 col-lg-12">
			<div class="jumbotron jumbotron-home">
				<div class="container-fluid">
					<h1>Add Student</h1><br/>

					<form class="form-horizontal" method="post" action="http://localhost/facerecognition/Students/input">
						<div class="form-group">
							<label class="col-sm-2 control-label">First Name</label>
							<div class="col-sm-4">
								<input type="text" class="form-control" name="firstname" placeholder="Enter firstname" required/>
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-2 control-label">Last Name</label>
							<div class="col-sm-4">
								<input type="text" class="form-control" name="lastname" placeholder="Enter lastname" required/>
							</div>
						</div>
						<div class="form-group">
							<label for="username" class="col-sm-2 control-label">Year & Section</label>
							<div class="col-sm-8">
								 <select class="form-control col-sm-3" name="sect_id" required>
					                <?php foreach($sections as $row) { ?> 
					                  <option value="<?php echo $row->sect_id; ?>"><?php echo $row->year_level;?><?php echo $row->block_name;?></option>';
					                <?php } ?>
					             </select>
				            </div>
						</div>
						<!-- <div class="form-group">
						    <label for="exampleFormControlFile1">Add Student Photo</label>
						    <input type="file" class="form-control-file" id="exampleFormControlFile1">
						</div> -->
						&nbsp;
						<button class="btn btn-primary" type="submit" value="submit">Submit</button>
            			<a class="btn btn-info" href="view_student">View List</a>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>

    <!-- Logout Modal-->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="<?= base_url(); ?>login/logout">Logout</a>
          </div>
        </div>
      </div>
    </div>