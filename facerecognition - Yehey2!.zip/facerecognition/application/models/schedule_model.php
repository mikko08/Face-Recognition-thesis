<?php


	class Schedule_model extends CI_Model {

	    var $sched_id = '';
	    var $class_id = '';
	    var $days = '';
        var $start = '';
        var $end_time = '';
	    

	    function __construct()
	    {
	        // Call the Model constructor
	        parent::__construct();
	        $this->load->library('session');
	        $this->load->model('schedule_model');
	    }


		function insert($data){

	       $a= $this->class_id = $data['class_id'];
	       $b= $this->days = $data['days'];
	      $c=  $this->start = $data['start'];
          $d=  $this->end_time = $data['end_time'];	       

            $sql = "SELECT * FROM schedule WHERE (class_id = '$a' AND days = '$b' AND start = '$c' AND end_time = '$d')";
            $query = $this->db->query($sql); 

        if ($query->num_rows() == 0) {

         $this->db->insert('schedule', $this);
            $this->session->set_flashdata('success', 'Schedule added.');
            //add to database

        } else { 


             $this->session->set_flashdata('error', 'Schedule already exists.');

                
                }

	        

            if (mysql_affected_rows !=NULL ){

            $this->session->set_flashdata('success', ' Schedule added.');
        }
    	}

    

    	function fetch_data($data){
  
    		 $query = $this->db->query("SELECT a.sched_id, a.class_id, 
                                           a.days, a.start, a.end_time,
                                           b.class_id, b.ins_id, b.sect_id,
                                           c.ins_id, c.lastname, c.firstname,
                                           d.sect_id, d.year_level, d.block_name, d.school_year, d.semester
                                    FROM schedule as a JOIN
                                         class as b JOIN
                                         instructor as c JOIN
                                         section as d WHERE
                                         a.class_id = b.class_id AND
                                         b.ins_id = c.ins_id AND
                                         b.sect_id = d.sect_id");
            return $query->result();

    	}

        function get_edit_schedule($sched_id)
        {
            
            $query = $this->db->select('*')->from('schedule')->where('sched_id', $sched_id)->get();
            return $query->result();
        }

         public function edit($data , $sched_id)
        {
            $this->db->where('sched_id', $sched_id);
            $this->db->update('schedule', $data);
        }
    	
    	function getClasses()
        {
            
           $query = $this->db->query("SELECT a.class_id, a.ins_id,
                                             b.ins_id, b.lastname, b.firstname
                                      FROM class as a JOIN
                                           instructor as b WHERE 
                                             a.ins_id = b.ins_id");
           return $query->result();
        }

        function getStartTime(){

            $query = $this->db->query("SELECT start FROM schedule");
            return $query->result();

        }

        function getEndTime(){

            $query = $this->db->query("SELECT end_time FROM schedule");
            return $query->result();

        }


       


}