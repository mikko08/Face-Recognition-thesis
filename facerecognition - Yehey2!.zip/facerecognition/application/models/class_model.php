<?php


	class Class_model extends CI_Model {

	    var $ins_id = '';
	    var $sect_id = '';
	    

	    function __construct()
	    {
	        // Call the Model constructor
	        parent::__construct();
	        $this->load->library('session');
	        $this->load->model('class_model');
	    }


		function insert($data){

            $b = $this->ins_id = $data['ins_id'];
            $c = $this->sect_id = $data['sect_id'];
           
            $sql = "SELECT * FROM class WHERE (ins_id = '$b' AND sect_id= '$c')";
            $query = $this->db->query($sql); 

         if ($query->num_rows() == 0) {

            $query = $this->db->query("CALL add_class('".$b."','".$c."')");
            mysqli_next_result($this->db->conn_id);
            $query->free_result();
            $this->session->set_flashdata('success', 'Class added.');
            //add to database

        } else { 

             $this->session->set_flashdata('error', 'Class already exists.');

                }


    	}

    
    	function fetch_data($data){
  
    		$query = $this->db->query("SELECT a.class_id,b.lastname,b.firstname,a.sect_id,a.date_created, c.year_level, c.block_name FROM class as a JOIN
          						  instructor as b JOIN
                                  section as c WHERE
            					  a.ins_id = b.ins_id AND a.sect_id = c.sect_id");
    		return $query;
    		
    	}

    	function getInstructor(){

    		$query = $this->db->query("SELECT ins_id, lastname, firstname FROM instructor");
    		return $query->result();
    	}

    	// function getSubject(){
 
    	// 	$query = $this->db->query("SELECT sub_code FROM subject");
    	// 	return $query->result();
    	// }

    	function getSection(){

    		$query = $this->db->query("SELECT sect_id, year_level, block_name FROM section");
    		return $query->result();
    	}




    	function get_edit_classes($class_id)
        {
            
            $query = $this->db->select('*')->from('class')->where('class_id', $class_id)->get();
            return $query->result();
        }


        public function edit($data , $class_id)
        {
            $this->db->where('class_id', $class_id);
            $this->db->update('class', $data);

             if (mysql_affected_rows !=NULL ){

            $this->session->set_flashdata('success', 'Class updated.');
        }else{
            $this->session->set_flashdata('error', 'Class not updated.');
              }
        }


}