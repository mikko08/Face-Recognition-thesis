<?php

	class View_model extends CI_Model{

    var $sect_id='';
    var $sub_code='';
    var $sub_name="";

	 function fetch_view($data){

      $query = $this->db->query("SELECT a.year_level, a.block_name, b.lastname, b.firstname FROM (section a INNER JOIN class c ON a.sect_id = c.sect_id JOIN instructor b on (c.ins_id = b.ins_id)) ");
    return $query->result();

    


    }

    function fetch_sect($data){

       $query = $this->db->query("SELECT * FROM section");
    return $query->result();
        
    }

  

 



}