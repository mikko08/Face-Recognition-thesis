<?php


	class subject_model extends CI_Model {
	    var $sub_code = '';
	    var $sub_name = '';

	    function __construct()
	    {
	        // Call the Model constructor
	        parent::__construct();
	        $this->load->library('session');
	    }


		function insert($data){

	        $a = $this->sub_code = $data['sub_code'];
	        $b = $this->sub_name = $data['sub_name'];

	         
            $sql = "SELECT * FROM subject WHERE (sub_code = '$a' AND sub_name = '$b')";
            $query = $this->db->query($sql); 

        if ($query->num_rows() == 0) {

            $query = $this->db->query("CALL add_subject('".$a."','".$b."')");
            mysqli_next_result($this->db->conn_id);
            $query->free_result();
            $this->session->set_flashdata('success', 'Subject added.');
            //add to database

        } else { 
            $this->session->set_flashdata('error', 'Subject already exists.');

                
                }
    	}

    	
    	function get_edit_subject($sub_code)
    	{
    		
    		$query = $this->db->select('*')->from('subject')->where('sub_code', $sub_code)->get();
    		return $query->result();
    	}


        public function edit($data , $sub_code)
        {
            $this->db->where('sub_code', $sub_code);
            $this->db->update('subject', $data);

             if (mysql_affected_rows != NULL) {

                $this->session->set_flashdata('success', 'Subject updated.');
            }else{
                $this->session->set_flashdata('error', 'Subject not updated.');
                
            }
        }


        function fetch_data(){

            $query = $this->db->query("SELECT * FROM subject ORDER BY sub_code DESC");
            return $query->result();
            
        }


}