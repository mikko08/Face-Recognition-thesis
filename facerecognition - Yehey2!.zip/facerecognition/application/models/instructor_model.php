<?php


	class instructor_model extends CI_Model {

		var $ins_id = '';
	    var $lastname = '';
	    var $firstname = '';

	    function __construct()
	    {
	        // Call the Model constructor
	        parent::__construct();
	        $this->load->library('session');
	    }


		function insert($data){

	       $a =  $this->firstname = $data['firstname'];
	       $b =  $this->lastname = $data['lastname'];


            $sql = "SELECT * FROM instructor WHERE (firstname = '$a' AND lastname = '$b')";
            $query = $this->db->query($sql); 

        if ($query->num_rows() == 0) {

            $query = $this->db->query("CALL add_instructor('".$a."','".$b."')");
            mysqli_next_result($this->db->conn_id);
            $query->free_result();
            $this->session->set_flashdata('success', 'Instructor added.');
            //add to database

        } else { 


             $this->session->set_flashdata('error', 'Instructor already exists.');

                
                }

    	}


    	function get_edit_instructor($ins_id)
    	{
    		$query = $this->db->select('*')->from('instructor')->where('ins_id', $ins_id)->get();
    		return $query->result();
    	}


    	public function edit($data , $ins_id)
		{
			$this->db->where('ins_id', $ins_id);
			$this->db->update('instructor', $data);

			if (mysql_affected_rows != NULL) {

                $this->session->set_flashdata('success', 'Instructor updated.');
            }else{
                $this->session->set_flashdata('error', 'Instructor not updated.');
                
            }
		}


    	public function fetch_data(){
    		$query = $this->db->query("SELECT * FROM instructor ORDER BY ins_id DESC");
    		return $query;
    	}

    	

}