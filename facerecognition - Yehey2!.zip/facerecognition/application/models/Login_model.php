<?php


class Login_model extends CI_Model
{
    public function login($data)
    {
        $query = $this->db->query("CALL login_auth('".$data['username']."','".$data['password']."')");
        mysqli_next_result($this->db->conn_id);
        if($query->num_rows() == 1)
        {
            $row = $query->result();
            $query->free_result();
            return $row;
        }
        else
        {
            return false;
        }
    }
    public function ins_login($data)
    {
        $query = $this->db->query("CALL user_login('".$data."')");
        mysqli_next_result($this->db->conn_id);
        $query->free_result();
    }
    public function ins_logout($data)
    {
        $query = $this->db->query("CALL user_logout('".$data."')");
        mysqli_next_result($this->db->conn_id);
        $query->free_result();
    }
}
