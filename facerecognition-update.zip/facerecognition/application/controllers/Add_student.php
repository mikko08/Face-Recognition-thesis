<?php

	class Add_student extends CI_Controller{

		public function student(){
			$this->load->view('templates/header');
			$this->load->view('pages/add_student');
			$this->load->view('templates/footer');
		}
	}

