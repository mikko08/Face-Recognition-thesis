<?php

	class Edit_student extends CI_Controller{

		public function faculty(){
			$this->load->view('templates/header');
			$this->load->view('pages/edit_student');
			$this->load->view('templates/footer');
		}
	}

