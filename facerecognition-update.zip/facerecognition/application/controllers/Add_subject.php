<?php

	class Add_subject extends CI_Controller{

		public function subject(){
			$this->load->view('templates/header');
			$this->load->view('pages/add_subject');
			$this->load->view('templates/footer');
		}
	}

