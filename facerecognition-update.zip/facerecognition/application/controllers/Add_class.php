<?php

	class Add_class extends CI_Controller{

		public function faculty(){
			$this->load->view('templates/header');
			$this->load->view('pages/Add_
				class');
			$this->load->view('templates/footer');
		}
	}

