<?php

	class Camera extends CI_Controller{

		public function camera(){
			$this->load->view('templates/header');
			$this->load->view('pages/camera.php');
			$this->load->view('templates/footer');
		}
	}

