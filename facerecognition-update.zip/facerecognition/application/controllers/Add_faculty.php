<?php

	class Add_faculty extends CI_Controller{

		public function faculty(){
			$this->load->view('templates/header');
			$this->load->view('pages/add_faculty');
			$this->load->view('templates/footer');
		}
	}

