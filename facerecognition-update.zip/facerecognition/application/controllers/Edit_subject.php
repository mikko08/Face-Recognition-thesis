<?php

	class Edit_subject extends CI_Controller{

		public function subject(){
			$this->load->view('templates/header');
			$this->load->view('pages/edit_subject');
			$this->load->view('templates/footer');
		}
	}

