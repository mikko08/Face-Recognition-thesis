<?php

	class Faculties extends CI_Controller{

		public function faculty(){
			$this->load->view('templates/header');
			$this->load->view('pages/faculties');
			$this->load->view('templates/footer');
		}
	}