<?php

	class Subject extends CI_Controller{

		public function charts(){
			$this->load->view('templates/header');
			$this->load->view('pages/subject');
			$this->load->view('templates/footer');
		}
	}

