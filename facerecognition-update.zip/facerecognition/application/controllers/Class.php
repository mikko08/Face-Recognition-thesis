<?php

	class Class extends CI_Controller{

		public function class(){
			$this->load->view('templates/header');
			$this->load->view('pages/class');
			$this->load->view('templates/footer');
		}
	}

