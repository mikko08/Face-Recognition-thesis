<?php

	class Edit_class extends CI_Controller{

		public function class(){
			$this->load->view('templates/header');
			$this->load->view('pages/edit_class');
			$this->load->view('templates/footer');
		}
	}

