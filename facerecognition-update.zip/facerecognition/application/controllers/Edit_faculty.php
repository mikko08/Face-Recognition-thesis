<?php

	class Edit_faculty extends CI_Controller{

		public function faculty(){
			$this->load->view('templates/header');
			$this->load->view('pages/edit_faculty');
			$this->load->view('templates/footer');
		}
	}

