<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <a class="navbar-brand" href="<?php echo base_url('Dashboard'); ?>">Face Recognition</a>
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
          <a class="nav-link" href="<?php echo base_url('Dashboard'); ?>">
            <i class="fa fa-fw fa-dashboard"></i>
            <span class="nav-link-text">Dashboard</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Camera">
          <a class="nav-link" href="<?php echo base_url('Camera'); ?>">
            <i class="fa fa-fw fa-camera"></i>
            <span class="nav-link-text">Camera</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Students">
          <a class="nav-link nav-link-collapse" data-toggle="collapse" href="#collapseComponentsss">
            <i class="fa fa-fw fa-list"></i>
            <span class="nav-link-text">Class</span>
          </a>
          <ul class="sidenav-second-level collapse" id="collapseComponentsss">
            <li>
                <a href="<?php echo base_url('Add_class'); ?>">Add Class</a>
            </li>
            <li>
                <a href="<?php echo base_url('Class'); ?>">View Classes</a>
            </li>
          </ul>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Students">
          <a class="nav-link nav-link-collapse" data-toggle="collapse" href="#collapseComponent">
            <i class="fa fa-fw fa-user"></i>
            <span class="nav-link-text">Faculty</span>
          </a>
          <ul class="sidenav-second-level collapse" id="collapseComponent">
            <li>
                <a href="<?php echo base_url('Add_faculty'); ?>">Add Faculty</a>
            </li>
            <li>
                <a href="<?php echo base_url('Faculties'); ?>">View Faculties</a>
            </li>
          </ul>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Students">
          <a class="nav-link nav-link-collapse" data-toggle="collapse" href="#collapseComponents">
            <i class="fa fa-fw fa-users"></i>
            <span class="nav-link-text">Students</span>
          </a>
          <ul class="sidenav-second-level collapse" id="collapseComponents">
            <li>
                <a href="<?php echo base_url('Add_student'); ?>">Add Student</a>
            </li>
            <li>
                <a href="<?php echo base_url('Students'); ?>">View Students</a>
            </li>
          </ul>
        </li>
         <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Students">
          <a class="nav-link nav-link-collapse" data-toggle="collapse" href="#collapseComponentss">
            <i class="fa fa-fw fa-book"></i>
            <span class="nav-link-text">Subject</span>
          </a>
          <ul class="sidenav-second-level collapse" id="collapseComponentss">
            <li>
                <a href="<?php echo base_url('Add_subject'); ?>">Add Subject</a>
            </li>
            <li>
                <a href="<?php echo base_url('Subject'); ?>">View Subject</a>
            </li>
          </ul>
        </li>
      </ul>
      <ul class="navbar-nav sidenav-toggler">
        <li class="nav-item">
          <a class="nav-link text-center" id="sidenavToggler">
            <i class="fa fa-fw fa-angle-left"></i>
          </a>
        </li>
      </ul>
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <form class="form-inline my-2 my-lg-0 mr-lg-2">
            <div class="input-group">
              <input class="form-control" type="text" placeholder="Search for...">
              <span class="input-group-btn">
                <button class="btn btn-primary" type="button">
                  <i class="fa fa-search"></i>
                </button>
              </span>
            </div>
          </form>
        </li>
        <li class="nav-item">
          <a class="nav-link" data-toggle="modal" data-target="#exampleModal">
            <i class="fa fa-fw fa-sign-out"></i>Logout</a>
        </li>
      </ul>
    </div>
  </nav 
<!--NAVIGATION NAVIGATION NAVIGATION NAVIGATION NAVIGATION-->

  <div class="content-wrapper">
  <div class="container-fluid">
  </br></br></br>
   <div class="card mb-3">
      <div class="card-header">
        <i class="fa fa-table"></i> Data Table Example</div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
              <tr>
                <th>ID</th>
                <th>Subject Code</th>
                <th>Instructor</th>
                <th>Year & Section</th>
                <th>Days</th>
                <th>Time</th>
                <th>Semester</th>
                <th>School Year</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>1</td>
                <td>Math101</td>
                <td>Sir Ome</td>
                <td>4R1</td>
                <td>Monday,Wednesday,Friday</td>
                <td>9:00am-10:00am</td>
                <td>1st Semester</td>
                <td>2017-2018</td>
                <td>Ongoing</td>
                <td><a class="btn btn-info" href="<?php echo base_url('Edit_class'); ?>">Edit</a></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
    </div>
  </div>
</div>
    
    <!-- Logout Modal-->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="#">Logout</a>
          </div>
        </div>
      </div>
    </div>