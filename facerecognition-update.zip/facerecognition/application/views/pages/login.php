  <div class="container">
    <div class="form mx-auto mt-5">
      <center><div class="card-header"><b>Login</b></div></center>
      <div class="card-body">
        <form>
          <div class="inputs b">
            <label>Username</label>
            <input class="input" id="username" type="username" placeholder="Enter username...">
          </div>

          <div class="input b">
            <label>Password</label>
            <input class="" id="password" type="password" placeholder="Enter password...">
          </div>
          <a class="btnnn btnn btn-block" href="<?php echo base_url('Dashboard'); ?>">Login</a>
        </form>
        &nbsp;
      </div>
    </div>
  </div>