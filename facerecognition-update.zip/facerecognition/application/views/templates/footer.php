		<br/>
		<script type="text/javascript" src="./assets/vendor/datatables/jquery.dataTables.js"></script>
	    <script type="text/javascript" src="./assets/vendor/jquery/jquery.min.js"></script>

	    <script type="text/javascript" src="./assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
	    
	    <script type="text/javascript" type="text/javascript" src="./assets/vendor/chart.js/Chart.min.js"></script>
	    <script type="text/javascript" src="./assets/vendor/datatables/jquery.dataTables.js"></script>
	    <script type="text/javascript" src="./assets/vendor/datatables/dataTables.bootstrap4.js"></script>
	
	    <script type="text/javascript" src="./assets/js/sb-admin.min.js"></script>
	    
	    <script type="text/javascript" src="./assets/js/sb-admin-datatables.min.js"></script>
	    <script type="text/javascript" src="./assets/js/sb-admin-charts.min.js"></script>
	    
	  </div>
  </body>
</html>