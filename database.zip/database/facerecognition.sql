-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 23, 2018 at 08:17 AM
-- Server version: 10.1.22-MariaDB
-- PHP Version: 7.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `facerecognition`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_class` (IN `instructor` VARCHAR(10), IN `blockname` VARCHAR(10))  NO SQL
BEGIN

SELECT @a:=COUNT(*) FROM class as a 
                   WHERE 
                   		a.ins_id = instructor AND
                        a.sect_id = blockname;
                        
                    
IF (@a=0)THEN
    INSERT INTO class(ins_id,sect_id) VALUES (instructor,blockname);
END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `add_class1` (IN `subcode` VARCHAR(10), IN `instructor` VARCHAR(50), IN `blockname` VARCHAR(10), IN `schoolyear` VARCHAR(10), IN `day` VARCHAR(10), IN `start` VARCHAR(10), IN `end` VARCHAR(10), IN `semester` VARCHAR(10))  NO SQL
BEGIN
SELECT @a:=COUNT(*) FROM class as a JOIN
						section as b JOIN 
                        subject as c JOIN
                        instructor as d JOIN
                        schedule as e 
                   WHERE a.ins_id = d.ins_id AND 					
                   		 a.sect_id = b.sect_id AND
                   		 a.sub_code = c.sub_code AND
                   		 e.class_id = a.class_id AND
                         d.lastname = instructor AND
                         b.block_name = blockname AND
                         b.semester = semester AND
                         b.school_year = schoolyear AND 
                         c.sub_code = subcode AND
                         e.days = day AND
                         e.start = start AND
                         e.end = end;
                         
SELECT @b:=ins_id FROM instructor as g WHERE g.lastname = instructor;
SELECT @c:=sect_id FROM section as h WHERE h.block_name = blockname;
IF (@a=0)THEN
    INSERT INTO class(ins_id,sect_id,sub_code) VALUES (@b,@c,subcode);
END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `add_instructor` (IN `firstname` VARCHAR(50), IN `lastname` VARCHAR(50))  NO SQL
BEGIN
   	SELECT @a:=COUNT(*) as Exist FROM instructor as a WHERE a.firstname=firstname AND a.lastname=lastname;
IF (@a=0)THEN
    INSERT INTO instructor(firstname,lastname,current_status) VALUES (firstname,lastname,'Working');
END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `add_section` (IN `bn` VARCHAR(10), IN `sy` VARCHAR(10), IN `sem` VARCHAR(10), IN `yl` TINYINT(4))  NO SQL
BEGIN
SELECT @a:=COUNT(*) FROM section as a 
                   WHERE a.block_name = bn AND
                   		 a.school_year = sy AND
                         a.semester = sem AND
                         a.year_level = yl;

IF(@a=0)THEN
    INSERT INTO section(block_name,school_year,semester,year_level) VALUES (bn,sy,sem,yl);
END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `add_student` (IN `fn` VARCHAR(50), IN `ln` VARCHAR(50), IN `se` VARCHAR(10))  NO SQL
BEGIN
SELECT @a:=COUNT(*) FROM student as a		
                   WHERE a.firstname = fn AND
                   		 a.lastname = ln AND
                         a.sect_id = se;

IF(@a=0)THEN
    INSERT INTO student(firstname,lastname,sect_id) VALUES (fn,ln,se);
END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `add_subject` (IN `code` VARCHAR(10), IN `name` VARCHAR(10))  NO SQL
BEGIN
SELECT @a:=COUNT(*) FROM subject as a 
					WHERE a.sub_code = code OR a.sub_name = name;

IF(@a=0)THEN
    INSERT INTO subject(sub_code,sub_name) VALUES (code,name);
END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `login_auth` (IN `uname` VARCHAR(50), IN `pass` VARCHAR(50))  NO SQL
SELECT * FROM users WHERE username = uname AND 
					password = pass$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `user_login` (IN `id` TINYINT)  NO SQL
UPDATE users SET user_status = 1 WHERE user_id = id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `user_logout` (IN `id` TINYINT)  NO SQL
UPDATE users SET user_status = 0 WHERE user_id = id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `view_class` (IN `id` INT)  NO SQL
SELECT a.class_id,c.sub_name as sub_name,CONCAT(b.firstname,' ',b.lastname) as lastname,d.block_name,e.days,e.start,e.end,a.date_created,d.semester,d.school_year FROM `class` as a JOIN
		instructor as b JOIN
        subject as c JOIN
        section as d JOIN
        schedule as e WHERE
a.ins_id = b.ins_id AND
a.sect_id = d.sect_id AND
a.class_id = e.class_id AND
a.ins_id = id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `view_class_id` (IN `id` INT)  NO SQL
SELECT a.class_id,c.sub_name as sub_name,CONCAT(b.firstname,' ',b.lastname) as lastname,d.block_name,e.days,e.start,e.end,a.date_created,d.semester,d.school_year FROM `class` as a JOIN
		instructor as b JOIN
        subject as c JOIN
        section as d JOIN
        schedule as e WHERE
a.ins_id = b.ins_id AND
a.sub_code = c.sub_code AND
a.sect_id = d.sect_id AND
a.class_id = e.class_id AND
a.class_id = id$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `array_attendance`
--

CREATE TABLE `array_attendance` (
  `array_id` int(10) NOT NULL,
  `array_sect_id` int(10) NOT NULL,
  `array_stud_id` int(10) NOT NULL,
  `array_attend_status` varchar(10) CHARACTER SET utf32 NOT NULL,
  `datetime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `class_attend_id` int(10) NOT NULL,
  `sect_id` int(10) NOT NULL,
  `stud_id` int(10) NOT NULL,
  `attend_status` varchar(10) NOT NULL DEFAULT 'absent',
  `datetime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf32;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`class_attend_id`, `sect_id`, `stud_id`, `attend_status`, `datetime`) VALUES
(17, 5, 2, 'present', '2018-02-23 12:24:49'),
(18, 5, 1, 'absent', '2018-02-23 12:24:49'),
(21, 5, 2, 'present', '2018-02-22 00:00:00'),
(22, 5, 1, 'present', '2018-02-22 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `class_id` int(10) NOT NULL,
  `ins_id` int(10) NOT NULL,
  `sect_id` int(10) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`class_id`, `ins_id`, `sect_id`, `date_created`) VALUES
(1, 30, 1, '2018-02-06 23:15:18'),
(2, 31, 5, '2018-02-07 14:59:03'),
(3, 35, 6, '2018-02-07 14:59:16'),
(4, 37, 5, '2018-02-07 15:11:15'),
(5, 39, 9, '2018-02-07 15:41:55');

-- --------------------------------------------------------

--
-- Table structure for table `class_details`
--

CREATE TABLE `class_details` (
  `cd_id` int(10) NOT NULL,
  `class_id` int(10) NOT NULL,
  `class_attend_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `instructor`
--

CREATE TABLE `instructor` (
  `ins_id` int(10) NOT NULL,
  `lastname` varchar(20) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `current_status` varchar(10) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `instructor`
--

INSERT INTO `instructor` (`ins_id`, `lastname`, `firstname`, `current_status`, `date_created`) VALUES
(30, 'Albia', 'Romel', 'Working', '2018-01-23 14:05:44'),
(31, 'Diaz', 'Mikko', 'Working', '2018-01-23 14:05:44'),
(32, 'Tyson', 'Ghodie', 'Working', '2018-01-29 22:49:05'),
(34, 'Diaz', 'Steph', 'Working', '2018-01-30 01:14:51'),
(35, 'Solis', 'Felix', 'Working', '2018-02-01 12:17:20'),
(36, 'Porte', 'Blink', 'Working', '2018-02-01 12:18:07'),
(37, 'Suede', 'Marsie', 'Working', '2018-02-01 12:19:35'),
(38, 'Karat', 'Dinesh', 'Working', '2018-02-01 12:21:11'),
(39, 'Baht', 'Alia', 'Working', '2018-02-01 12:22:27'),
(40, 'Flowers', 'Lily', 'Working', '2018-02-01 12:33:02');

-- --------------------------------------------------------

--
-- Table structure for table `section`
--

CREATE TABLE `section` (
  `sect_id` int(10) NOT NULL,
  `year_level` tinyint(4) NOT NULL,
  `block_name` varchar(10) NOT NULL,
  `school_year` enum('2016-2017','2017-2018','2018-2019','2019-2020') NOT NULL,
  `semester` enum('1st','2nd') NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `section`
--

INSERT INTO `section` (`sect_id`, `year_level`, `block_name`, `school_year`, `semester`, `date_created`) VALUES
(5, 4, 'Rizal', '2017-2018', '2nd', '2018-02-06 14:13:00');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `stud_id` int(10) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `sect_id` int(10) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`stud_id`, `firstname`, `lastname`, `sect_id`, `date_created`) VALUES
(1, 'Romel', 'Albia', 5, '2018-02-23 10:17:11'),
(2, 'Kaye', 'Timada', 5, '2018-02-23 10:55:22');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `sub_code` varchar(10) NOT NULL,
  `stud_id` int(10) DEFAULT NULL,
  `att_id` int(10) DEFAULT NULL,
  `sect_id` int(10) DEFAULT NULL,
  `sub_name` varchar(50) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`sub_code`, `stud_id`, `att_id`, `sect_id`, `sub_name`, `date_created`) VALUES
('CHEM10', NULL, NULL, NULL, 'General Chemistry', '2018-02-06 23:08:27'),
('ENG10', NULL, NULL, NULL, 'Speech', '2018-02-06 23:07:03'),
('Math10', NULL, NULL, NULL, 'Algebra', '2018-02-06 23:06:22'),
('PE10', NULL, NULL, NULL, 'Exercise', '2018-02-06 23:07:34'),
('PHY10', NULL, NULL, NULL, 'General Physics', '2018-02-06 23:07:59'),
('SS20', NULL, NULL, NULL, 'Psychology', '2018-02-06 23:06:39');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(10) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `position` enum('Admin','Instructor') NOT NULL,
  `user_status` tinyint(4) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `lastname`, `firstname`, `username`, `password`, `position`, `user_status`, `date_created`) VALUES
(30, 'Albia', 'Romel', 'instructor', 'instructor', 'Instructor', 0, '2018-01-23 22:16:41'),
(31, 'Diaz', 'Clyde', 'admin', 'admin', 'Admin', 1, '2018-01-23 22:16:41');

--
-- Triggers `users`
--
DELIMITER $$
CREATE TRIGGER `insert_logs` AFTER UPDATE ON `users` FOR EACH ROW IF (NEW.user_status = 0) THEN 
	INSERT INTO user_logs(user_id,status) VALUES(OLD.user_id,2);
ELSEIF (NEW.user_status = 1) THEN
	INSERT INTO user_logs(user_id,status) VALUES(OLD.user_id,1);
END IF
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `user_logs`
--

CREATE TABLE `user_logs` (
  `log_id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `timedate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_logs`
--

INSERT INTO `user_logs` (`log_id`, `user_id`, `status`, `timedate`) VALUES
(33, 31, 1, '2018-01-24 12:11:36'),
(34, 31, 2, '2018-01-24 12:11:44'),
(35, 30, 1, '2018-01-24 12:11:57'),
(36, 30, 2, '2018-01-24 12:12:03'),
(37, 31, 1, '2018-01-24 12:12:09'),
(38, 31, 2, '2018-01-24 13:03:54'),
(39, 31, 1, '2018-01-24 13:04:00'),
(40, 31, 2, '2018-01-24 13:04:29'),
(41, 30, 1, '2018-01-24 13:04:36'),
(42, 31, 1, '2018-01-24 16:05:31'),
(43, 31, 2, '2018-01-24 16:05:34'),
(44, 31, 1, '2018-01-24 16:06:54'),
(45, 31, 2, '2018-01-24 16:06:58'),
(46, 30, 1, '2018-01-24 16:07:09'),
(47, 30, 2, '2018-01-24 16:20:50'),
(48, 30, 1, '2018-01-24 16:25:44'),
(49, 30, 2, '2018-01-24 16:27:01'),
(50, 31, 1, '2018-01-24 16:27:05'),
(51, 31, 2, '2018-01-24 16:32:50'),
(52, 31, 1, '2018-01-24 16:33:03'),
(53, 31, 2, '2018-01-24 16:46:03'),
(54, 30, 1, '2018-01-24 16:46:11'),
(55, 30, 2, '2018-01-24 16:53:18'),
(56, 30, 1, '2018-01-24 16:55:14'),
(57, 30, 2, '2018-01-24 16:55:21'),
(58, 31, 1, '2018-01-24 16:55:26'),
(59, 31, 2, '2018-01-24 17:14:23'),
(60, 31, 1, '2018-01-24 17:14:28'),
(61, 31, 2, '2018-01-24 17:14:32'),
(62, 30, 1, '2018-01-24 17:14:38'),
(63, 30, 2, '2018-01-24 17:16:35'),
(64, 31, 1, '2018-01-24 17:16:41'),
(65, 30, 1, '2018-01-24 20:55:29'),
(66, 30, 2, '2018-01-24 20:55:49'),
(67, 31, 1, '2018-01-24 20:57:00'),
(68, 31, 1, '2018-01-26 21:59:52'),
(69, 31, 1, '2018-01-27 10:02:20'),
(70, 31, 1, '2018-01-27 22:43:59'),
(71, 31, 1, '2018-01-28 23:59:40'),
(72, 31, 1, '2018-01-29 01:51:18'),
(73, 31, 1, '2018-01-29 05:06:57'),
(74, 31, 1, '2018-01-29 12:19:13'),
(75, 31, 1, '2018-01-29 22:21:44'),
(76, 31, 1, '2018-01-30 01:24:14'),
(77, 30, 1, '2018-01-30 12:23:27'),
(78, 30, 2, '2018-01-30 12:24:28'),
(79, 31, 1, '2018-01-30 12:24:35'),
(80, 31, 1, '2018-01-30 12:56:57'),
(81, 31, 1, '2018-01-30 13:40:59'),
(82, 31, 1, '2018-01-31 21:48:51'),
(83, 31, 1, '2018-02-01 10:50:46'),
(84, 31, 2, '2018-02-01 13:21:55'),
(85, 30, 1, '2018-02-01 13:22:09'),
(86, 30, 1, '2018-02-01 19:21:35'),
(87, 30, 2, '2018-02-01 19:24:10'),
(88, 30, 1, '2018-02-01 19:24:19'),
(89, 30, 1, '2018-02-01 20:03:39'),
(90, 31, 1, '2018-02-01 20:53:24'),
(91, 31, 1, '2018-02-02 10:36:52'),
(92, 31, 1, '2018-02-02 10:38:00'),
(93, 31, 2, '2018-02-02 10:38:03'),
(94, 30, 1, '2018-02-02 10:38:17'),
(95, 30, 1, '2018-02-02 12:31:08'),
(96, 30, 1, '2018-02-02 16:48:28'),
(97, 30, 2, '2018-02-02 18:29:49'),
(98, 30, 1, '2018-02-02 18:29:59'),
(99, 31, 1, '2018-02-04 22:07:22'),
(100, 31, 2, '2018-02-04 22:07:55'),
(101, 30, 1, '2018-02-04 22:08:07'),
(102, 30, 2, '2018-02-04 22:10:51'),
(103, 31, 1, '2018-02-04 22:11:00'),
(104, 31, 2, '2018-02-04 22:11:22'),
(105, 30, 1, '2018-02-04 22:13:25'),
(106, 30, 2, '2018-02-04 22:39:36'),
(107, 30, 1, '2018-02-04 22:47:53'),
(108, 30, 2, '2018-02-04 23:25:20'),
(109, 31, 1, '2018-02-04 23:25:23'),
(110, 31, 2, '2018-02-04 23:25:42'),
(111, 30, 1, '2018-02-04 23:25:47'),
(112, 30, 2, '2018-02-04 23:30:26'),
(113, 31, 1, '2018-02-04 23:30:33'),
(114, 31, 2, '2018-02-04 23:31:04'),
(115, 30, 1, '2018-02-04 23:33:54'),
(116, 30, 2, '2018-02-04 23:33:58'),
(117, 31, 1, '2018-02-04 23:34:31'),
(118, 31, 2, '2018-02-04 23:34:40'),
(119, 30, 1, '2018-02-05 00:03:19'),
(120, 30, 2, '2018-02-05 01:24:03'),
(121, 30, 1, '2018-02-05 01:24:10'),
(122, 30, 1, '2018-02-05 08:26:52'),
(123, 31, 1, '2018-02-05 22:46:39'),
(124, 31, 1, '2018-02-06 08:12:02'),
(125, 31, 2, '2018-02-06 08:18:25'),
(126, 30, 1, '2018-02-06 08:18:34'),
(127, 30, 1, '2018-02-06 09:10:29'),
(128, 31, 1, '2018-02-06 16:08:37'),
(129, 31, 2, '2018-02-06 16:14:44'),
(130, 31, 1, '2018-02-06 16:14:52'),
(131, 31, 2, '2018-02-06 16:38:09'),
(132, 31, 1, '2018-02-06 16:38:16'),
(133, 31, 2, '2018-02-06 16:51:15'),
(134, 30, 1, '2018-02-06 16:51:22'),
(135, 30, 2, '2018-02-06 16:52:09'),
(136, 30, 1, '2018-02-06 16:52:20'),
(137, 30, 2, '2018-02-06 16:56:35'),
(138, 30, 1, '2018-02-06 16:56:49'),
(139, 30, 2, '2018-02-06 16:59:03'),
(140, 30, 1, '2018-02-06 16:59:10'),
(141, 30, 2, '2018-02-06 17:05:26'),
(142, 31, 1, '2018-02-06 17:05:35'),
(143, 31, 2, '2018-02-06 18:20:39'),
(144, 31, 1, '2018-02-06 18:20:47'),
(145, 31, 2, '2018-02-06 18:20:51'),
(146, 31, 1, '2018-02-06 18:20:55'),
(147, 31, 2, '2018-02-06 18:21:01'),
(148, 31, 1, '2018-02-06 18:21:11'),
(149, 31, 2, '2018-02-06 18:21:18'),
(150, 31, 1, '2018-02-06 18:21:23'),
(151, 31, 2, '2018-02-06 18:21:34'),
(152, 31, 1, '2018-02-06 18:21:38'),
(153, 31, 2, '2018-02-06 18:21:44'),
(154, 31, 1, '2018-02-06 18:21:49'),
(155, 31, 2, '2018-02-06 18:22:00'),
(156, 31, 1, '2018-02-06 18:22:06'),
(157, 31, 2, '2018-02-06 18:22:15'),
(158, 31, 1, '2018-02-06 18:22:19'),
(159, 31, 2, '2018-02-06 18:22:26'),
(160, 31, 1, '2018-02-06 18:22:34'),
(161, 31, 2, '2018-02-06 18:22:44'),
(162, 31, 1, '2018-02-06 18:22:50'),
(163, 31, 2, '2018-02-06 18:22:58'),
(164, 31, 1, '2018-02-06 18:23:05'),
(165, 31, 2, '2018-02-06 18:23:17'),
(166, 31, 1, '2018-02-06 18:23:24'),
(167, 31, 2, '2018-02-06 18:26:54'),
(168, 31, 1, '2018-02-06 18:27:02'),
(169, 31, 2, '2018-02-06 18:30:00'),
(170, 31, 1, '2018-02-06 18:30:13'),
(171, 31, 2, '2018-02-06 18:32:37'),
(172, 31, 2, '2018-02-06 18:34:24'),
(173, 31, 1, '2018-02-06 18:34:28'),
(174, 31, 2, '2018-02-06 18:40:23'),
(175, 31, 1, '2018-02-06 18:41:59'),
(176, 31, 2, '2018-02-06 18:42:17'),
(177, 31, 1, '2018-02-06 18:42:32'),
(178, 31, 2, '2018-02-06 18:52:16'),
(179, 31, 1, '2018-02-06 18:52:29'),
(180, 31, 2, '2018-02-06 18:52:35'),
(181, 31, 1, '2018-02-06 18:52:42'),
(182, 31, 2, '2018-02-06 18:52:49'),
(183, 31, 1, '2018-02-06 18:52:53'),
(184, 31, 2, '2018-02-06 18:57:31'),
(185, 30, 1, '2018-02-06 18:57:46'),
(186, 31, 1, '2018-02-06 19:33:48'),
(187, 30, 1, '2018-02-06 22:20:29'),
(188, 30, 1, '2018-02-06 22:28:46'),
(189, 30, 2, '2018-02-06 22:37:58'),
(190, 31, 1, '2018-02-06 22:38:01'),
(191, 31, 1, '2018-02-06 23:02:10'),
(192, 31, 2, '2018-02-07 19:18:07'),
(193, 30, 1, '2018-02-07 19:18:22'),
(194, 30, 2, '2018-02-07 19:22:57'),
(195, 30, 1, '2018-02-07 19:23:04'),
(196, 31, 1, '2018-02-23 12:28:32'),
(197, 31, 1, '2018-02-23 12:30:30'),
(198, 30, 1, '2018-02-23 12:30:39'),
(199, 30, 2, '2018-02-23 12:30:59'),
(200, 31, 1, '2018-02-23 12:31:05'),
(201, 31, 1, '2018-02-23 12:40:47'),
(202, 31, 1, '2018-02-23 12:45:03'),
(203, 31, 1, '2018-02-23 12:46:07'),
(204, 31, 1, '2018-02-23 12:58:37'),
(205, 31, 1, '2018-02-23 13:03:22'),
(206, 31, 1, '2018-02-23 13:03:29'),
(207, 31, 1, '2018-02-23 13:05:04'),
(208, 31, 1, '2018-02-23 13:05:19'),
(209, 31, 1, '2018-02-23 13:21:14'),
(210, 30, 1, '2018-02-23 13:21:22'),
(211, 30, 1, '2018-02-23 14:47:42'),
(212, 30, 2, '2018-02-23 14:53:41'),
(213, 30, 1, '2018-02-23 14:55:28'),
(214, 30, 2, '2018-02-23 15:15:01'),
(215, 31, 1, '2018-02-23 15:15:09');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `array_attendance`
--
ALTER TABLE `array_attendance`
  ADD PRIMARY KEY (`array_id`);

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`class_attend_id`),
  ADD KEY `attendance_ibfk_2` (`stud_id`);

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`class_id`),
  ADD KEY `ins_id` (`ins_id`);

--
-- Indexes for table `class_details`
--
ALTER TABLE `class_details`
  ADD PRIMARY KEY (`cd_id`),
  ADD KEY `class_attend_id` (`class_attend_id`),
  ADD KEY `class_details_ibfk_1` (`class_id`);

--
-- Indexes for table `instructor`
--
ALTER TABLE `instructor`
  ADD PRIMARY KEY (`ins_id`);

--
-- Indexes for table `section`
--
ALTER TABLE `section`
  ADD PRIMARY KEY (`sect_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`stud_id`),
  ADD KEY `sect_id` (`sect_id`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`sub_code`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_logs`
--
ALTER TABLE `user_logs`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `array_attendance`
--
ALTER TABLE `array_attendance`
  MODIFY `array_id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `class_attend_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `class`
--
ALTER TABLE `class`
  MODIFY `class_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `class_details`
--
ALTER TABLE `class_details`
  MODIFY `cd_id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `instructor`
--
ALTER TABLE `instructor`
  MODIFY `ins_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;
--
-- AUTO_INCREMENT for table `section`
--
ALTER TABLE `section`
  MODIFY `sect_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `stud_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT for table `user_logs`
--
ALTER TABLE `user_logs`
  MODIFY `log_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=216;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendance`
--
ALTER TABLE `attendance`
  ADD CONSTRAINT `attendance_ibfk_2` FOREIGN KEY (`stud_id`) REFERENCES `student` (`stud_id`) ON UPDATE CASCADE;

--
-- Constraints for table `class`
--
ALTER TABLE `class`
  ADD CONSTRAINT `class_ibfk_1` FOREIGN KEY (`ins_id`) REFERENCES `instructor` (`ins_id`);

--
-- Constraints for table `class_details`
--
ALTER TABLE `class_details`
  ADD CONSTRAINT `class_details_ibfk_1` FOREIGN KEY (`class_id`) REFERENCES `class` (`class_id`),
  ADD CONSTRAINT `class_details_ibfk_2` FOREIGN KEY (`class_attend_id`) REFERENCES `attendance` (`class_attend_id`);

--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `student_ibfk_1` FOREIGN KEY (`sect_id`) REFERENCES `section` (`sect_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
