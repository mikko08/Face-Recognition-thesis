<?php

    class Attendance_model extends CI_Model{

 

     function fetch_att($data){

         $sect_id = $this->uri->segment(3); 
    //or $articleId = $this->uri->segment(4); depends on your structure

       //Do your checks here
       if (isset($sect_id) && !empty($sect_id)) {
             
                
           

                    $query = $this->db->query(" SELECT   date(a.datetime) as date, a.attend_status, stu.stud_id, stu.lastname, stu.firstname
    FROM
     (attendance a INNER JOIN student stu ON
         a.stud_id = stu.stud_id
         JOIN section sec on (a.sect_id = sec.sect_id))
          WHERE sec.sect_id =".$sect_id ." order by stu.stud_id");
                    return $query->result();

         }


    

    }

    function fetch_stud($data){
        $sect_id = $this->uri->segment(3); 
        //or $articleId = $this->uri->segment(4); depends on your structure

       //Do your checks here
       if (isset($sect_id) && !empty($sect_id)) {
         $query = $this->db->query("SELECT stu.stud_id, stu.lastname, stu.firstname
                                    FROM (attendance a INNER JOIN student stu 
                                    ON a.stud_id = stu.stud_id
                                    JOIN section sec on (a.sect_id = sec.sect_id))
                                    WHERE sec.sect_id =".$sect_id ." 
                                    GROUP BY stu.stud_id");
       }
        return $query->result();
    }

function att_h($data){
     $sect_id = $this->uri->segment(3); 
    //or $articleId = $this->uri->segment(4); depends on your structure

       //Do your checks here
       if (isset($sect_id) && !empty($sect_id)) {
            $query = $this->db->query("SELECT DISTINCT date(datetime) AS date
                FROM attendance");
                    return $query->result();


       }

}


function v_month($data){
     $sect_id = $this->uri->segment(3); 
    //or $articleId = $this->uri->segment(4); depends on your structure

       //Do your checks here
       if (isset($sect_id) && !empty($sect_id)) {
            $query = $this->db->query("SELECT DISTINCT MONTHNAME(a.datetime) AS date FROM  (
               attendance a  JOIN section sec on (a.sect_id = sec.sect_id))
          WHERE sec.sect_id =".$sect_id);
                    return $query->result();


       }

}

            function fetch_sect($data){

       $query = $this->db->query("SELECT * FROM section");
    return $query->result();
        
    }

 



}