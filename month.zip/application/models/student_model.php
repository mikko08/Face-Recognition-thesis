<?php


	class student_model extends CI_Model {

	    var $lastname = '';
	    var $firstname = '';
	    var $sect_id = '';

	    function __construct()
	    {
	        // Call the Model constructor
	        parent::__construct();
	        $this->load->library('session');
	    }


		function insert($data){

	        $a = $this->firstname = $data['firstname'];
	        $b = $this->lastname = $data['lastname'];
	        $c = $this->sect_id = $data['sect_id'];

            $sql = "SELECT * FROM student WHERE (firstname = '$a' AND lastname = '$b' AND sect_id = '$c')";
            $query = $this->db->query($sql); 

        if ($query->num_rows() == 0) {

            $query = $this->db->query("CALL add_student('".$a."','".$b."','".$c."')");
            mysqli_next_result($this->db->conn_id);
            $query->free_result();
            $this->session->set_flashdata('success', 'Student added.');
            //add to database

        } else { 
            $this->session->set_flashdata('error', 'Student already exists.');

                
                }
    	}



    	function get_edit_students($stud_id)
    	{
    		
    		$query = $this->db->select('*')->from('student')->where('stud_id', $stud_id)->get();
    		return $query->result();
    	}


        public function edit($data , $stud_id)
        {
            $this->db->where('stud_id', $stud_id);
            $this->db->update('student', $data);

             if (mysql_affected_rows != NULL) {

                $this->session->set_flashdata('success', 'Student updated.');
            }else{
                $this->session->set_flashdata('error', 'Student not updated.');
                
            }
        }


    	function fetch_data(){

    		$query = $this->db->query("SELECT a.stud_id,a.firstname,a.lastname,b.sect_id,b.block_name, b.year_level,a.date_created FROM student as a JOIN
          							           section as b WHERE
            						           a.sect_id = b.sect_id");
    		return $query;
    		
    	}

    

    	function getSection(){

    		$query = $this->db->query("SELECT sect_id, year_level, block_name FROM section");
    		return $query->result();
    	}

}