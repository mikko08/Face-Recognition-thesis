<?php

	class Dashboard_model extends CI_Model{

	 function fetch_class($data){

          $query = $this->db->query("SELECT a.class_id,b.lastname,b.firstname,a.sect_id,date(a.date_created) as d, c.year_level, c.block_name FROM class as a JOIN
                        instructor as b JOIN
                                  section as c WHERE
                        a.ins_id = b.ins_id AND a.sect_id = c.sect_id");
        return $query->result();
            
        }

     // function fetch_sched($data){
  
    	// 	 $query = $this->db->query("SELECT a.sched_id, a.class_id, 
     //                                       a.days, a.start, a.end_time,
     //                                       b.class_id, b.ins_id, b.sect_id,
     //                                       c.ins_id, c.lastname, c.firstname,
     //                                       d.sect_id, d.year_level, d.block_name, d.school_year, d.semester
     //                                FROM schedule as a JOIN
     //                                     class as b JOIN
     //                                     instructor as c JOIN
     //                                     section as d WHERE
     //                                     a.class_id = b.class_id AND
     //                                     b.ins_id = c.ins_id AND
     //                                     b.sect_id = d.sect_id");
     //    return $query->result();
    		
    	// }


}