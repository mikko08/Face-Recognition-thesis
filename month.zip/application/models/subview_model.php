<?php

	class Subview_model extends CI_Model{

 

	 function fetch_sub($data){

         $sect_id = $this->uri->segment(3); 
    //or $articleId = $this->uri->segment(4); depends on your structure

       //Do your checks here
       if (isset($sect_id) && !empty($sect_id)) {
             $query = $this->db->query("
                 SELECT 
                  sec.year_level,
                 sec.block_name,
                 sub.sub_code ,
                 sub.sub_name
                FROM section as sec
                JOIN subject as sub
                ON sec.sect_id = sub.sect_id 
                 WHERE sec.sect_id =
                 ".$sect_id);
                return $query->result();
         }


    

    }


            function fetch_sect($data){

       $query = $this->db->query("SELECT * FROM section");
    return $query->result();
        
    }

 



}