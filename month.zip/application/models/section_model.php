<?php


	class section_model extends CI_Model {

	    var $year_level = '';
	    var $block_name = '';
	    var $semester = '';
	    var $school_year = '';

	    function __construct()
	    {
	        // Call the Model constructor
	        parent::__construct();
	        $this->load->library('session');
	    }


		function insert($data){
            $a = $this->year_level = $data['year_level'];
            $b = $this->block_name = $data['block_name'];
            $c = $this->semester = $data['semester'];
            $d = $this->school_year = $data['school_year'];
            
	       

	     $sql = "SELECT * FROM section WHERE (year_level = '$a' AND block_name = '$b' AND semester = '$c' AND school_year = '$d')";
            $query = $this->db->query($sql); 

        if ($query->num_rows() == 0) {

             $query = $this->db->query("CALL add_section('".$b."','".$d."','".$c."','".$a."')");
            mysqli_next_result($this->db->conn_id);
            $query->free_result();
            $this->session->set_flashdata('success', 'Section added.');
            //add to database

        } else { 


             $this->session->set_flashdata('error', 'Section already exists.');

                
                }          
    	}

    	function get_edit_section($sect_id)
    	{
    		
    		$query = $this->db->select('*')->from('section')->where('sect_id', $sect_id)->get();
    		return $query->result();
    	}


        public function edit($data , $sect_id)
        {
            $this->db->where('sect_id', $sect_id);
            $this->db->update('section', $data);


            if (mysql_affected_rows != NULL) {

                $this->session->set_flashdata('success', 'Section updated.');
            }else{
                $this->session->set_flashdata('error', 'Section not updated.');
                
            }
        
        }


    

    	function fetch_data(){


    		$query = $this->db->query("SELECT * FROM section ORDER BY sect_id DESC");
    		return $query;
    		
    	}

        function fetch(){

            $query = $this->db->query("SELECT year_level FROM section");
            return $query;

        }

}