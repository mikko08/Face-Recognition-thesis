SET @SQL = NULL;
SELECT
  GROUP_CONCAT(DISTINCT
    CONCAT(
      'sum(case when Date_format(a.datetime, ''%Y-%M'') = ''',
      dt,
      ''' then a.attend_status else 0 end) AS `',
      dt, '`'
    )
  ) INTO @SQL
FROM
(
  SELECT Date_format(a.datetime, '%Y-%M') AS dt
  FROM attendance a
  ORDER BY a.datetime
) d;
 
SET @SQL 
  = CONCAT('SELECT s.lastname, ', @SQL, ' 
            from student s
            inner join attendance a
              on s.stud_id = a.stud_id
            inner join section se
              on a.sect_id = se.sect_id
            group by s.lastname;');
 
PREPARE stmt FROM @SQL;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

 SELECT   a.datetime, attend.status, stu.stud_id, stu.lastname
    FROM
     (attendance a INNER JOIN student stu ON
         a.stud_id = stu.stud_id)   group by stu.stud_id 

         SELECT   date(a.datetime), a.attend_status, stu.stud_id, stu.lastname
    FROM
     (attendance a INNER JOIN student stu ON
         a.stud_id = stu.stud_id
         JOIN section sec on (a.sect_id = sec.sect_id))
          WHERE sec.sect_id =".$sect_id ." 
         
         group by stu.stud_id 