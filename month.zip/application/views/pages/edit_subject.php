


<div class="content-wrapper">
    <div class="container-fluid">
    <div class="col-sm-9 col-xs-9 col-md-10 col-lg-12">
      <div class="jumbotron jumbotron-home">
        <div class="container-fluid">
          <h1>Edit Subject</h1><br/>

         <form class="form-horizontal" role="form" method="post" action="http://localhost/facerecognition/Subject/getEditSubject/<?php echo $subjects['0']->sub_code; ?>">
         
          <div class="form-group">
            <label  class="col-sm-4 control-label">Subject Code</label>
            <div  class="col-sm-4">
              <?php foreach($subjects as $row) { ?> 
                 <input type="text" class="form-control" id="" name="sub_code" value="<?php echo $row->sub_code; ?>" />
             <?php } ?>
            </div>
          </div>

          <div class="form-group">
            <label class="col-sm-4 control-label">Subject Name</label>
            <div  class="col-sm-4">
              <?php foreach($subjects as $row) { ?> 
                 <input  type="text" class="form-control" id="" name="sub_name" value="<?php echo $row->sub_name; ?>" />
              <?php } ?>
            </div>
          </div>
          <button class="btn btn-primary" type="submit" value="submit">Submit</button>
          <button class="btn btn-info" href="<?php echo base_url('Subject/view_subjects'); ?>">Cancel</button>
        </form>
          
        </div>
      </div>
    </div>
  </div>
</div>




