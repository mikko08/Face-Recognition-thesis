<?php if($this->session->flashdata('error')){  ?>
        <div class="alert alert-danger">
            <a href="#" class="close" data-dismiss="alert">&times;</a>
            <strong>Error!</strong> <?php echo $this->session->flashdata('error'); ?>
        </div>
    <?php }else if($this->session->flashdata('blank')){  ?>
        <div class="alert alert-danger">
            <a href="#" class="close" data-dismiss="alert">&times;</a>
            <strong>Error!</strong> <?php echo $this->session->flashdata('blank'); ?>
        </div>
    <?php } ?>
  <div class="container">
    <div class="form mx-auto mt-5">
      <center><div class="card-header"><b>Login</b></div></center>
      <div class="card-body">
         <?= form_open('login/auth_user'); ?>
          <div class="input b">
            <label>Username</label>
            <?php
              $input_name = array(
                  'name' => 'username',
                  'type' => 'text',
                  'class' => 'form-control',
                  'placeholder' => 'Username');
              echo form_input($input_name);
            ?>
          </div><br/>

          <div class="inputs b">
            <label>Password</label>
            <?php
              $input_pass = array(
                  'name' => 'password',
                  'type' => 'password', 
                  'class' => 'form-control',
                  'placeholder' => 'Password');
              echo form_input($input_pass);
            ?>
          </div><br/><br/>
          <button class="btnnn btnn btn-block" type="submit" >Login</button>
        
        &nbsp;
      </div>
    </div>
  </div>