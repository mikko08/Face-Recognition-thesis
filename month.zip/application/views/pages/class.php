
<!--NAVIGATION NAVIGATION NAVIGATION NAVIGATION NAVIGATION-->

  <div class="content-wrapper">
  <div class="container-fluid">
  </br></br></br>
     <?php if($this->session->flashdata('success')){  ?>
        <div class="alert alert-success">
            <a href="#" class="close" data-dismiss="alert">&times;</a>
            <strong>Success!</strong> <?php echo $this->session->flashdata('success'); ?>
        </div>
    <?php }else{
     if($this->session->flashdata('error')){
        ?>
        <div class="alert alert-danger">
            <a href="#" class="close" data-dismiss="alert">&times;</a>
            <strong>Error!</strong> <?php echo $this->session->flashdata('error'); ?>
        </div>
    <?php }
    }  ?> 
    
   <div class="card mb-3">
      <div class="card-header">
        <i class="fa fa-table"></i> Classes</div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
              <tr>
                <th>Instructor</th>
                <th>Section</th>
                <th>Date_created</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
            <!-- <?php var_dump($fetch_data) ?> -->

            <?php
              foreach ($fetch_data->result() as $row) {
            ?>
              <tr>  

               <td><?php echo $row->lastname; ?>, <?php echo $row->firstname; ?></td>
               <td><?php echo $row->year_level; ?><?php echo $row->block_name; ?></td>
               <td><?php echo $row->date_created; ?></td>
               <td>
               <a class="btn btn-info" href="<?php echo base_url('Class_controller/getEdit/') . $row->class_id; ?>">Edit</a>
               </td>
              </tr>

            <?php
            }
            ?>

            </tbody>
          </table>
        </div>
      </div>
      <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
    </div>
  </div>
</div>
    
    <!-- Logout Modal-->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="<?= base_url(); ?>login/logout">Logout</a>
          </div>
        </div>
      </div>
    </div>