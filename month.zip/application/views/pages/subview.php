

  <!--NAVIGATION NAVIGATION NAVIGATION NAVIGATION NAVIGATION-->
  
  <div class="content-wrapper">
    <div class="container-fluid">
      <br/><br/><br/>
      
      <!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-table"></i> Subjects</div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
             <thead>
              <tr>
                <th>Subject Code</th>
                <th>Subject Name</th>
                <th>Attendance List</th>
              </tr>
            </thead>
            <tbody>
             <?php
              foreach ($subjects as $row) {
            ?>

              <tr>  
               <td><a href="<?php echo base_url('attendance/attendance');?>"><?php echo $row->sub_code?></a></td>
               <td><a href="<?php echo base_url('attendance/attendance');?>"><?php echo $row->sub_name?></a></td>
               <td><a href="<?php echo base_url('attendance/attendance')?>" class="btn btn-success">View</a></td>

              </tr>

            <?php
            }
            ?>
            </tbody>
          </table>
          </div>
        </div>
        <div class="card-footer small text-muted"><a  href="<?php echo base_url('view/view');?>" class="btn btn-warning">Back</a></div>

      </div>
    </div>
  </div>