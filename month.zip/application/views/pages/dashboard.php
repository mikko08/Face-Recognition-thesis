
  <!--NAVIGATION NAVIGATION NAVIGATION NAVIGATION NAVIGATION-->
  
  <div class="content-wrapper">
    <div class="container-fluid">
      <br/><br/>
        <?php if($this->session->flashdata('welcome')){  ?>
        <div class="alert alert-success">
            <a href="#" class="close" data-dismiss="alert">&times;</a>
            <strong>Hello!</strong> <?php echo $this->session->flashdata('welcome'); ?>
        </div>
        <?php }?><br/>
      <!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-table"></i> Registered classes</div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
             <thead>
              <tr>
                <th>Class ID</th>
                <th>Teacher</th>
                <th>Section</th>
                <th>Date_created</th>
              </tr>
            </thead>
            <tbody>
             <?php
              foreach ($fetch_class as $row) {
            ?>
              <tr>  
               <td><?php echo $row->class_id; ?></td>
               <td><?php echo $row->lastname. ', ' .$row->firstname; ?></td>
               <td><?php echo $row->year_level. '-'. $row->block_name; ?></td>
               <td><?php echo $row->d; ?></td>
              </tr>

            <?php
            }
            ?>
            </tbody>
          </table>
          </div>
        </div>
        <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
      </div>
    </div>
  </div>

    <!-- Logout Modal-->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">"Are you sure you want to logout?"</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="<?= base_url(); ?>login/logout">Logout</a>
          </div>
        </div>
      </div>
    </div>