

  <!--NAVIGATION NAVIGATION NAVIGATION NAVIGATION NAVIGATION-->
  
  <div class="content-wrapper">
    <div class="container-fluid">
      <br/><br/><br/>
      
      <!-- Example DataTables Card-->
       <!-- <div class="dropdown">
          <button class="btn btn-default dropdown-toggle" type="button" data-toggle="dropdown">Monthly Reports
          <span class="caret"></span></button>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <b class="dropdown-item">School Year</b>
            <li><a class="dropdown-item dropdown-toggle" href="#">2017-2018</a>
              <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="#">January</a></li>
                    <li><a class="dropdown-item" href="#">February</a></li>
                    <li><a class="dropdown-item" href="#">March</a></li>
                    <li><a class="dropdown-item" href="#">April</a></li>
                    <li><a class="dropdown-item" href="#">May</a></li>
                    <li><a class="dropdown-item" href="#">June</a></li>
                    <li><a class="dropdown-item" href="#">July</a></li>
                    <li><a class="dropdown-item" href="#">August</a></li>
                    <li><a class="dropdown-item" href="#">September</a></li>
                    <li><a class="dropdown-item" href="#">October</a></li>
                    <li><a class="dropdown-item" href="#">November</a></li>
                    <li><a class="dropdown-item" href="#">December</a></li>
                </ul>
            </li>
            <li><a class="dropdown-item dropdown-toggle" href="#">2018-2019</a>
              <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="#">January</a></li>
                    <li><a class="dropdown-item" href="#">February</a></li>
                    <li><a class="dropdown-item" href="#">March</a></li>
                    <li><a class="dropdown-item" href="#">April</a></li>
                    <li><a class="dropdown-item" href="#">May</a></li>
                    <li><a class="dropdown-item" href="#">June</a></li>
                    <li><a class="dropdown-item" href="#">July</a></li>
                    <li><a class="dropdown-item" href="#">August</a></li>
                    <li><a class="dropdown-item" href="#">September</a></li>
                    <li><a class="dropdown-item" href="#">October</a></li>
                    <li><a class="dropdown-item" href="#">November</a></li>
                    <li><a class="dropdown-item" href="#">December</a></li>
                </ul>
            </li>
            <li><a class="dropdown-item dropdown-toggle" href="#">2019-2020</a>
              <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="#">January</a></li>
                    <li><a class="dropdown-item" href="#">February</a></li>
                    <li><a class="dropdown-item" href="#">March</a></li>
                    <li><a class="dropdown-item" href="#">April</a></li>
                    <li><a class="dropdown-item" href="#">May</a></li>
                    <li><a class="dropdown-item" href="#">June</a></li>
                    <li><a class="dropdown-item" href="#">July</a></li>
                    <li><a class="dropdown-item" href="#">August</a></li>
                    <li><a class="dropdown-item" href="#">September</a></li>
                    <li><a class="dropdown-item" href="#">October</a></li>
                    <li><a class="dropdown-item" href="#">November</a></li>
                    <li><a class="dropdown-item" href="#">December</a></li>
                </ul>
            </li>
          </ul>
        </div><br/>
 -->

    <div class="form-group">
                <label for="name" class="col-sm-2 control-label">Monthly Report</label>
                <select class="col-sm-3 form-control" name="month">
                      <?php foreach($v_month as $row) { ?> 
                        <option value="<?php echo $row->date; ?>"><?php echo $row->date;?></option>;
                      <?php } ?>
                </select>
                <a  href="#" class="btn btn-success">Okay</a>
              </div>
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-table"></i> Attendance Record &nbsp;</div>

        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">

             <thead>

              <tr>
                <th>Student Name</th>
              <!--  <?php var_dump($att_h) ?>  -->
                 <?php
                 foreach($att_h as $date):
            ?>
                  <th><?= $date->date; ?></th>
         <?php
                endforeach;
            ?>
             </tr>
            </thead>
            <tbody>
         <!--<?php var_dump($att_d) ?>-->

        <?php
              foreach ($fetch_stud as $row) {          
            ?>
              <tr>  

               <td><?php echo $row->stud_id.'. ' . $row->lastname. ', ' . $row->firstname; ?></td>
               <?php
                  for($i=0;$i<count($att_h);$i++){
                      for($x=0;$x<count($att_d);$x++){
                          if($row->stud_id == $att_d[$x]->stud_id && $att_d[$x]->date == $att_h[$i]->date){
                              echo "<td>".$att_d[$x]->attend_status."</td>";
                          }
                      }
                  }
               ?>

              </tr>
        <?php
           }//end foreach fetch_stud
            ?>
            </tbody>
          </table>
          </div>
        </div>
        <div class="card-footer small text-muted"><a  href="<?php echo base_url('view/view');?>" class="btn btn-warning">Back</a></div>

      </div>
    </div>
  </div>