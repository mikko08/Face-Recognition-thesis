


<div class="content-wrapper">
    <div class="container-fluid">
    <div class="col-sm-9 col-xs-9 col-md-10 col-lg-12">
      <div class="jumbotron jumbotron-home">
        <div class="container-fluid">
          <h1>Edit Instructor</h1><br/>

         <form class="form-horizontal" role="form" method="post" action="http://localhost/facerecognition/Instructors/getEditInstructors/<?php echo $instructors['0']->ins_id; ?>">
         
          <div class="form-group">
            <label  class="col-sm-4 control-label">Firstname</label>
            <div  class="col-sm-4">
              <?php foreach($instructors as $row) { ?> 
                 <input type="text" class="form-control" id="" name="firstname" value="<?php echo $row->firstname; ?>" />
             <?php } ?>
            </div>
          </div>

          <div class="form-group">
            <label class="col-sm-4 control-label">Lastname</label>
            <div  class="col-sm-4">
              <?php foreach($instructors as $row) { ?> 
                 <input  type="text" class="form-control" id="" name="lastname" value="<?php echo $row->lastname; ?>" />
              <?php } ?>
            </div>
          </div>
          <button class="btn btn-primary" type="submit" value="submit">Submit</button>
        </form>
          
        </div>
      </div>
    </div>
  </div>
</div>




