<?php

	class Section extends CI_Controller{

		public function view_section(){
	        if($this->session->userdata('logged'))
	        {
				$this->load->model('section_model');
	       		$data["fetch_data"] = $this->section_model->fetch_data();
				$this->load->view('templates/header');
				$this->load->view('pages/section', $data);
				$this->load->view('templates/footer');		
	       	}
		}

		public function add_section(){
	        if($this->session->userdata('logged'))
	        {
				$this->load->view('templates/header');
				$this->load->view('pages/add_section');
				$this->load->view('templates/footer');
	       	}
		}

		public function input() {
	        if($this->session->userdata('logged'))
	        {
				if(
					$this->input->post('year_level') != "" &&
					$this->input->post('block_name') != ""  &&
					$this->input->post('semester') != ""  &&
					$this->input->post('school_year') != ""
				)
				{

					$data['year_level'] = $this->input->post('year_level');
					$data['block_name'] = $this->input->post('block_name');
					$data['semester'] = $this->input->post('semester');
					$data['school_year'] = $this->input->post('school_year');
					$this->load->model('section_model');
					$this->section_model->insert($data);

				}
				else{
					
				}
			}
	        else
	        {
	            redirect('login/');
	        }
			redirect("Section/view_section");

		}


		public function getEdit($sect_id){

			$this->load->model('section_model');
			$data["sections"] = $this->section_model->get_edit_section($sect_id);
			$this->load->view('templates/editHeader');
			$this->load->view('pages/edit_section', $data);
			$this->load->view('templates/editFooter');


		}


		public function getEditSections($sect_id) {
	        if($this->session->userdata('logged'))
	        {

				if(
					$this->input->post('year_level') != "" &&
					$this->input->post('block_name') != ""  &&
					$this->input->post('semester') != ""  &&
					$this->input->post('school_year') != ""
				)
				{

					$data['year_level'] = $this->input->post('year_level', TRUE);
					$data['block_name'] = $this->input->post('block_name', TRUE);
					$data['semester'] = $this->input->post('semester', TRUE);
					$data['school_year'] = $this->input->post('school_year', TRUE);
					$this->load->model('section_model');
					$this->section_model->edit($data, $sect_id);

				}
				else{
					
				}
	       	}  

				redirect("Section/view_section");
		}


	}