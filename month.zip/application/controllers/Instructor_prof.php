<?php

	class Instructor_prof extends CI_Controller{

		public function index(){
			if($this->session->userdata('logged'))
        	{
				$this->load->view('templates/header');
				$this->load->view('pages/instructor');
				$this->load->view('templates/footer');
	       	}
	        else
	        {
	            redirect('login/');
	        }
		}

		public function instructor_log(){
			$this->load->view('templates/header');
			$this->load->view('pages/instructor');
			$this->load->view('templates/footer');
		}
	}

