<?php

	class Login extends CI_Controller {

	   public function __construct()
	    {
	        parent::__construct();
	        $this->load->model('login_model');

	    }

	    public function index()
	    {

	        if(isset($this->session->userdata['logged']))
	        {
	            $this->load->view('templates');
	        }else{
	            $this->load->view('login');
	        }
	    }

	    public function auth_user()
	    {
	        $this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean');
	        $this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean');

	          
	        if($this->form_validation->run() == TRUE)
	        {
	            $data = array(
	              'username' => $this->input->post('username'),
	              'password' => $this->input->post('password')
	            );

	          
	            $result = $this->login_model->login($data);
	 
	            if($result == TRUE)
	            {   //get user info
	                $user_id = $result[0]->user_id;
	                $user_type = $result[0]->position;
	                $this->login_model->ins_login($user_id);
	                $session_data = array(
	                    'logged' => true,
	                    'user_id' => $result[0]->user_id,
	                    'firstname' => $result[0]->firstname,
	                    'lastname' => $result[0]->lastname
	                );


	                $this->session->set_userdata($session_data);
	                if($user_type == 'Admin'){
	                	$this->session->set_flashdata('welcome','Login successful.');
	                	redirect('Dashboard/dashboards');
	                }
	                if($user_type == 'Instructor'){
	                	$this->session->set_flashdata('welcome','Login successful.');
	                	redirect('view/view');
	            	}	
	            }
	            else
	            {

					$this->session->set_flashdata('error','Username and/or password is invalid');
	                redirect('login/');
	            }
	        }
			else  {
				if($this->form_validation->run() == FALSE ){
	             $err = validation_errors();
   				$err = $err. $this->session->set_flashdata('blank','Username and password are required.'). redirect('login/');
   				
	            }
	    	}
	    }

	    public function logout()
	    {
	    	$this->login_model->ins_logout($this->session->userdata('user_id'));
	        mysqli_next_result($this->db->conn_id);
	   		$this->session->unset_userdata('logged',
	   			'user_id',
	   			'firstname',
	   			'lastname');
	   		$data['message_display'] = 'Successfully logged out';

			redirect('login/');
		
	    }
	}